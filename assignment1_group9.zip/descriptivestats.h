#pragma once
#include "libdeclarations.h"

/*
NOTE:
	- Function parameters that mean the same thing:
			+ "datapoint* arg_list" and "datapoint dataset[]" 
			+ "int list_size" and "int count"

	- The difference in naming and approach exists because the functions are
	written by different members of the team who are either comfortable
	with approaching the data structure with a pointer or with an array.
*/

datapoint calculateMedian(datapoint* arg_list, int list_size);
datapoint calculateMode(datapoint* arg_list, int list_size);
datapoint calculateMean(datapoint dataset[], int count);
datapoint calculateVariance(datapoint data[], int count, datapoint mean);
datapoint calculateStdev(datapoint var);
datapoint calculateMAD(datapoint data[], int count, datapoint mean);
datapoint calculateThirdQuartile(datapoint* arg_list, int list_size);
datapoint calculateSkewness(datapoint data[], int count, datapoint mean, datapoint stdev);
datapoint calculateKurtosis(datapoint data[], int count, datapoint mean, datapoint stdev);

/*
Cuong Vu

NOTE:
	- This function calculates the median of x and y.
*/

datapoint calculateMedian(datapoint* arg_list, int list_size) {
	datapoint median;

	/*
	NOTE:
		- This part is used to sort the x and y data points and
		sort them into dynamic arrays of type double using the
		quicksort function provided by Dr. Minh Dinh.
	*/
	double* arr_x = new double[list_size];
	double* arr_y = new double[list_size];

	for (int index = 0; index < list_size; index++) {
		*(arr_x + index) = (arg_list + index)->x;
	}
	for (int index = 0; index < list_size; index++) {
		*(arr_y + index) = (arg_list + index)->y;
	}
	quickSort(arr_x, 0, list_size - 1);
	quickSort(arr_y, 0, list_size - 1);

	/*
	NOTE:
		- The statement below is used to check if the number of
		elements in the list is an even or an odd number.
		If it's even then the modulus operation will return 0
		whereas if it's odd then the modulus operation will
		return 1. Similar to true or false.

		- With that said, if(list_size%2) will only execute if
		the size of the list is odd because if list_size is odd
		then list_size%2=1.
	*/

	if (list_size % 2) {
		median.x = arr_x[(list_size - 1) / 2];
		median.y = arr_y[(list_size - 1) / 2];
	}
	else if (!(list_size % 2)) {
		/*
		NOTE:
			- If the data set size is even then the median
			is the two middle numbers added together and
			diveded by 2.
		*/
		median.x = (arr_x[list_size / 2 - 1] + arr_x[list_size / 2]) / 2;
		median.y = (arr_y[list_size / 2 - 1] + arr_y[list_size / 2]) / 2;
	}

	delete[] arr_x;
	delete[] arr_y;

	return median;
}

/*
Cuong Vu

NOTE:
	- This function calculates the mode of the data set for x and y.
*/

datapoint calculateMode(datapoint* arg_list, int list_size) {
	datapoint mode;
	mode.x = 0;
	mode.y = 0;
	/*
	NOTE:
		- This part is used to sort the x and y data points and
		sort them into dynamic arrays of type double using the
		quicksort function provided by Dr. Minh Dinh.
	*/
	double* arr_x = new double[list_size];
	double* arr_y = new double[list_size];

	for (int index = 0; index < list_size; index++) {
		*(arr_x + index) = (arg_list + index)->x;
	}
	for (int index = 0; index < list_size; index++) {
		*(arr_y + index) = (arg_list + index)->y;
	}
	quickSort(arr_x, 0, list_size - 1);
	quickSort(arr_y, 0, list_size - 1);

	/*
	NOTE:
		- The variable type 'double' current_val_x is
		the unrepeated value for the list. If the previous
		value is different from the current value then
		'current_val_x' changes and the 'current_count' for 
		the new value starts again.
	*/
	double current_val_x = *arr_x;
	for (int index = 0, max_count = 0, current_count = 0; index < list_size; index++) {
		current_count += 1;
		if (current_val_x != *(arr_x + index)) {
			current_val_x = *(arr_x + index);
			/*
			NOTE:
				- Setting the current count to 1 because 
				as 'current_val_x' is being assigned, it's
				also being counted once.
			*/
			current_count = 1;
		}
		if (current_count > max_count) {
			max_count = current_count;
			mode.x = current_val_x;
		}
	}

	/*
	NOTE:
		- The statements below work similarly to the ones
		above.
	*/
	double current_val_y = *arr_y;
	for (int index = 0, max_count = 0, current_count = 0; index < list_size; index++) {
		current_count += 1;
		if (current_val_y != *(arr_y + index)) {
			current_val_y = *(arr_y + index);
			/*
			NOTE:
				- Similarly, setting the current count to 1 because
				as 'current_val_x' is being assigned, it's
				also being counted once.
			*/
			current_count = 1;
		}
		if (current_count > max_count) {
			max_count = current_count;
			mode.y = current_val_y;
		}
	}

	delete[] arr_x;
	delete[] arr_y;

	return mode;
}

/*
Anh Tran

NOTE:
	- This function calculates the mean of x and y.

	- In main():
		datapoint mean = calculateMean(data, count);
*/
datapoint calculateMean(datapoint dataset[], int count) {
	datapoint mean;
	//get sum of x
	double sum_x = 0;
	for (int i = 0; i < count; i++) {
		sum_x += dataset[i].x;
	}
	mean.x = sum_x / count; //mean of x

	//get sum of y
	double sum_y = 0;
	for (int i = 0; i < count; i++) {
		sum_y += dataset[i].y;
	}
	mean.y = sum_y / count; //mean of y

	return mean;
}

/*
Anh Tran

NOTE:
	- This function calculates and prints out variance
	VARIANCE^2 = (sum of (x[i] - mean_x)^2)/(count - 1)
	count here is number of datapoint

	- In main:
		datapoint variance = calculateVariance(data, count,mean);
*/
datapoint calculateVariance(datapoint data[], int count, datapoint mean) {
	datapoint variance;
	variance.x = 0; variance.y = 0; //initialize

  //first calculate the numerator: (sum of (x[i] - mean_x)^2)
	for (int i = 0; i < count; i++) {
		variance.x += pow((data[i].x - mean.x), 2);
		variance.y += pow((data[i].y - mean.y), 2);
	}//end loop

	//divide it by (number of x(y) values - 1)
	variance.x = variance.x / (count - 1);
	variance.y = variance.y / (count - 1);

	return variance;
}

/*
Anh Tran

NOTE:
	- This function calculates standard deviation
	Standard deviation is square root of variance

	- In main:
	datapoint stdev = calculateStdev(variance);
*/
datapoint calculateStdev(datapoint var) {
	datapoint stdev;
	stdev.x = sqrt(var.x); //stdev_x
	stdev.y = sqrt(var.y); //stdev_y

	return stdev;
}

/*
Anh Tran

NOTE:
	- This function calculates Mean Absolute Deviations
	MAD (of x) = (sum of absolute of (x[i] - mean_x))/count

	- In main:
		datapoint mad = calculateMAD(data, count, mean);
*/
datapoint calculateMAD(datapoint data[], int count, datapoint mean) {
	/*
	NOTE:
		- mad.x is mad_xand mad.y is mad_y
	*/
	datapoint mad;
	mad.x = 0; mad.y = 0;

	/*
	NOTE:
		- First calculate the numerator which is sum of absolute
		of (x[i] - mean_x) noted absolute -> use fabs()
	*/
	for (int i = 0; i < count; i++) {
		mad.x += fabs(data[i].x - mean.x);
		mad.y += fabs(data[i].y - mean.y);
	}

	/*
	NOTE:
		- Then divide it by the number of data points in the 
		data set.
	*/
	mad.x = mad.x / count;
	mad.y = mad.y / count;

	return mad;
}

/*
Vu Tran

NOTE:
	- This function is used to calculate third quartile.
	Partial solution is derived from or similar to
	the solution in calculateMedian().

	- In main:
		datapoint Q3 = calculateThirdQuartile(datapoint* arg_list, list_size);
	*/
datapoint calculateThirdQuartile(datapoint* arg_list, int list_size)
{
	datapoint thirdQ;

	thirdQ.x = 0; thirdQ.y = 0; // initialize

	double* arr_x = new double[list_size];
	double* arr_y = new double[list_size];

	for (int index = 0; index < list_size; index++) {
		*(arr_x + index) = (arg_list + index)->x;
	}
	for (int index = 0; index < list_size; index++) {
		*(arr_y + index) = (arg_list + index)->y;
	}
	quickSort(arr_x, 0, list_size - 1);
	quickSort(arr_y, 0, list_size - 1);

	/*
	NOTE:
		- For n=odd
	*/
	if (list_size % 2)
	{
		/*
		NOTE:
			- For each side of median, total values = odd
		*/
		int eachSideSecondQOdd = list_size / 2;
		/*
		NOTE:
			- For n = odd, and each side is odd
		*/
		if (eachSideSecondQOdd % 2) {
			thirdQ.x = arr_x[((list_size - 1) / 2) + ((eachSideSecondQOdd / 2) + 1)];
			thirdQ.y = arr_y[((list_size - 1) / 2) + ((eachSideSecondQOdd / 2) + 1)];
		}
		/*
		NOTE:
			- For n = odd, but each side is even
		*/
		else if (!(eachSideSecondQOdd % 2))
		{
			thirdQ.x = (arr_x[((list_size - 1) / 2) + ((eachSideSecondQOdd / 2) + 1)]
				+ arr_x[((list_size - 1) / 2) + (eachSideSecondQOdd / 2)]) / 2;
			thirdQ.y = (arr_y[((list_size - 1) / 2) + ((eachSideSecondQOdd / 2) + 1)]
				+ arr_y[((list_size - 1) / 2) + (eachSideSecondQOdd / 2)]) / 2;
		}
	}
	else if (!(list_size % 2))
	{
		/*
		NOTE:
			- For n = even, but each side is odd
		*/
		int eachSideSecondQEven = list_size / 2;
		if (eachSideSecondQEven % 2) {
			thirdQ.x = arr_x[(list_size / 2) + (eachSideSecondQEven / 2)];
			thirdQ.y = arr_y[(list_size / 2) + (eachSideSecondQEven / 2)];
		}
		/*
		NOTE:
			- For n = even, and each side is even
		*/
		else if (!(eachSideSecondQEven % 2))
		{
			thirdQ.x = (arr_x[(list_size / 2) + (eachSideSecondQEven / 2)]
				+ arr_x[(list_size / 2) + ((eachSideSecondQEven / 2) - 1)]) / 2;
			thirdQ.y = (arr_y[(list_size / 2) + (eachSideSecondQEven / 2)]
				+ arr_y[(list_size / 2) + ((eachSideSecondQEven / 2) - 1)]) / 2;
		}
	}

	delete[] arr_x;
	delete[] arr_y;

	return thirdQ;
}

/*
Vu Tran

 NOTE:
	- This function is used to calculate skewness

	- In main:
		datapoint skewness = calculateSkewness(data, count, mean, stdev);
	  */
datapoint calculateSkewness(datapoint data[], int count, datapoint mean, datapoint stdev)
{
	datapoint skew;

	skew.x = 0; skew.y = 0; // initialize

	for (int i = 0; i < count; i++)
	{
		
		/*
		NOTE:
			- This calculates  sum of(((x[i] - mean_x) / stdev) ^ 3) and y
		*/
		skew.x += pow(((data[i].x - mean.x) / stdev.x), 3);
		skew.y += pow(((data[i].y - mean.y) / stdev.y), 3);
	}

	/*
	NOTE:
		- This is sum of(((x[i] - mean_x) / stdev) ^ 3) / count and y 
	*/ 
	skew.x /= count;
	skew.y /= count;
	return skew;
}

/*
Cuong Vu

NOTE:
	- This function calculates the peakedness (Kurtosis)
	of the data set for x and y. Partial solution is derived 
	from or similar to the solution in calculateSkew().

	- In main:
		datapoint kurtosis=calculateKurtosis(datapoint* arg_list, list_size);
*/
datapoint calculateKurtosis(datapoint data[], int count, datapoint mean, datapoint stdev) {
	datapoint kurtosis;
	kurtosis.x = 0;
	kurtosis.y = 0;

	for (int i = 0; i < count; i++)
	{
		/*
		NOTE:
			- This calculates the sum within the sigma notation.
		*/
		kurtosis.x += pow(((data[i].x - mean.x) / stdev.x), 4);
		kurtosis.y += pow(((data[i].y - mean.y) / stdev.y), 4);
	}

	/*
	NOTE:
		- Dividing the whole thing by the size of the list.
	*/
	kurtosis.x = (kurtosis.x / count) - 3;
	kurtosis.y = (kurtosis.y / count) - 3;

	return kurtosis;
}





