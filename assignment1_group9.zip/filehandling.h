#pragma once
#include "libdeclarations.h"

bool checkFloat(const string& arg);
double strToFloat(const string& arg);
int dataListSize(const string& file_name);
int parseFile(const string& file_name, datapoint* arg_list);


/*
Cuong Vu

NOTE:
    - This function is to check if a string is a valid float or not.
*/
bool checkFloat(const string& arg) {
    for (int index = 0, decpoint_count = 0, sign_count = 0, digit_count = 0; index < arg.length(); index++) {
        /*
        NOTE:
            - This is to check if the input contains any characters that are not
            allowed as well as to check if the characters aren't where they are
            supposed to be. For example, '1-2' or '23-' is not allowed.
        */
        if ((arg[index] < '0' && (arg[index] != '.' && arg[0] != '-' && arg[0] != '+'))
            || arg[index] > '9') {
            return 0;
        }

        /*
        NOTE:
            - This is to check if the input contains more than one decimal point.
            For example, '1.2.45.12' or anything as such is not allowed.
        */
        if (arg[index] == '.') {
            decpoint_count++;
        }
        if (decpoint_count > 1) {
            return 0;
        }

        /*
        NOTE:
            - This is to check if the input contains more than one sign.
            For example, '--124' or '+-+131.2' is not allowed.
        */
        if (arg[index] == '-' || arg[index] == '+') {
            sign_count++;
        }
        if (sign_count > 1) {
            return 0;
        }

        /*
        NOTE:
            - This is to check if the input actually has any numerical digits.
            For example, if the user inputs '-.' or '+' or '.' then they
            are all invalid floating point numbers.
        */
        if (arg[index] >= '0' && arg[index] <= '9') {
            digit_count++;
        }
        if (index == arg.length() - 1 && digit_count == 0) {
            return 0;
        }
    }
    return 1;
}

/*
Cuong Vu

NOTE:
    - This function is manually written to convert a string into
    an integer. This is based on the ASCII table where the
    character '0' corresponds to the integer value of 48.
*/
double strToFloat(const string& arg) {
    if (!checkFloat(arg)) {
        cerr << "Error: the input is not a floating point. Function strToFloat() returned 0." << endl;
        return false;
    }

    const int TRANSLATION_FACTOR = '0';
    const int BASE = 10;
    double result = 0;
    int decimal_point_pos = arg.length();

    /*
    NOTE:
        -The part below is to check where the position of decimal point is
        for the string to double conversion in the following parts.
    */
    for (int index = 0; index < arg.length(); index++) {
        if (arg[index] == '.') {
            decimal_point_pos = index;
        }
    }

    /*
    NOTE:
        - The part below is used to convert the string argument into an integer/double.
        The whole woggly thing looks hideous and complicated but the idea behind the algorithm
        is very simple.

        - The first 'for' loop is used to convert the numbers BEFORE the decimal point into
        a double. Therefore, it has an incrementing positive exponent for every digit to the left.
        The base is 10 because decimal means 10. If there is a negative sign, the loop will exit
        because if left there, it could yield very bizzare values. If the argument has the format
        '.1339' or '-.231339' then the first 'for' loop will exit and the result will be set to 0.

        - On the contrary, the second 'for' loop is used to convert the numbers AFTER the decimal point
        into a double. Hence, it has a decrementing negative exponent for every digit to the right.
    */
    for (int index = decimal_point_pos - 1, exponent = 0; index >= 0; index--, exponent++) {
        if (decimal_point_pos == 0) {
            result = 0;
            break;
        }
        char temp = arg[index];
        if (temp == '-') {
            break;
        }
        temp -= TRANSLATION_FACTOR;
        result += (temp * pow(BASE, exponent));
    }
    for (int index = decimal_point_pos + 1, exponent = -1; index < arg.length(); index++, exponent--) {
        char temp = arg[index];
        temp -= TRANSLATION_FACTOR;
        result += (temp * pow(BASE, exponent));
    }

    /*
    NOTE:
        - The statement below is implemented to check for a negative
        sign in the string and negate the result if a negative sign
        is detected.
    */
    if (arg[0] == '-') {
        result = -result;
    }

    return result;
}

/*
Cuong Vu

NOTE:
    - This function is to get the number of data sets
    in any given file.
*/
int dataListSize(const string& file_name) {
    int data_list_size = 0;

    ifstream file_in;
    file_in.open(file_name, ios::in);

    if (!file_in) {
        cerr << "Error: the file does not exist. Function dataListSize() returned 0." << endl;
        return 0;
    }

    for (char next = '\0', temp = '\0'; !file_in.eof();) {
        temp = next;
        file_in.get(next);
        if (next == '\n') {
            /*
            NOTE:
                - This part is to check whether redundant new lines
                have been inserted in the file. If the variable
                'next' and the variable 'temp' are both new lines
                then the skipped and continued into the next
                iteration.
            */
            if (temp == '\n') {
                continue;
            }
            data_list_size += 1;
        }
    }

    file_in.close();

    return data_list_size;
}

/*
Cuong Vu

    NOTE:
        - This function is used to import the data sets from the
        file(s) and store them into a dynamically allocated
        array of the 'datapoint' struct via passing by reference.
        The function does not return any value.
*/
int parseFile(const string& file_name, datapoint* arg_list) {
    ifstream file_in;
    file_in.open(file_name, ios::in);

    if (!file_in) {
        cerr << "Error: the file does not exist. Function parseFile() returned 0." << endl;
        return 0;
    }
    /*
    NOTE:
        - The 'for' loop below is used to ignore the first line
        with 'x' and 'y' characters
    */
    for (char nf = '\0'; nf != '\n'; file_in.get(nf));

    string temp_str;
    int index = 0;
    for (char temp = '\0', next = '\0'; ; ) {
        temp = next;
        file_in.get(next);
        /*
        NOTE:
            - The conditional statement below is used to check
            if there are multiple new lines in the file so we
            could ignore those unecessary new lines.
        */
        if (temp == '\n' && next == '\n') {
            continue;
        }
        /*
        NOTE:
            - The statements below are used to check if a comma
            or a new line has been detected to end the string
            concatenation from the file input.
        */
        if (next == ',') {
            (arg_list + index)->x = strToFloat(temp_str);
            temp_str.clear();
            continue;
        }
        /*
        NOTE:
             - The conditional statement below checks if there's a
             new line or if the end of the input file has been reached.
             If eof()>0 then the loop will be terminated.
        */
        else if (next == '\n' || file_in.eof()) {
            (arg_list + index)->y = strToFloat(temp_str);
            if (file_in.eof()) {
                break;
            }
            index++;
            temp_str.clear();
            continue;
        }
        temp_str += next;
    }

    file_in.close();
    return 1;
}

/*
Cuong Vu

    NOTE:
        - This function is used to print the X and the Y components
        individually
*/
void printComponents(datapoint* arg_list, int list_size) {
    string print_option = "\0";
    cout << "Print the components (not recommended for large files)? (y/n): ";
    cin >> print_option;
    if (print_option != "y" && print_option != "n") {
        cerr << "Error: invalid command. Function printComponents() recursed. " << endl;
        printComponents(arg_list, list_size);
    }
    if (print_option == "n") {
        return;
    }
    else if (print_option == "y") {
        cout << endl;
        cout << "X-components: ";
        for (int index = 0; index < list_size; index++) {
            cout << (arg_list + index)->x;
            if (index != list_size - 1) {
                cout << ",";
            }
        }
        cout << endl << endl;
        cout << "Y-components: ";
        for (int index = 0; index < list_size; index++) {
            cout << (arg_list + index)->y;
            if (index != list_size - 1) {
                cout << ",";
            }
        }
        cout << endl;
    }
}