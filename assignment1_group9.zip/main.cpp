/*
                RMIT University
        Software Engineering Design - EEET2482
                Group 9 Assigment 1

Author 1: VU TRAN MINH CUONG (s3878779)
Author 2: TRAN MINH ANH (s3931980)
Author 3: PHAM DANG KHOA (s3884419)
Author 4: TRAN HOANG VU (s3915185)

Date: 22/11/2021
*/

#include "filehandling.h"
#include "descriptivestats.h"
#include "inferentialstats.h"

int main(int argc, char* argv[]) {
    if (argc != 2) {
        cerr << "Error: invalid input. The format is "
            << ".\\assignment1_group9.exe <filename>.csv. ";
        cerr << "Function main() returned 0." << endl;
        return 0;
    }

    cout << endl;

    int list_size = dataListSize(argv[1]);
    datapoint* dataset = new datapoint[list_size];
    if (!parseFile(argv[1], dataset)) {
        cerr << "Error: parsing failed. Function main() returned 0." << endl;
        return 0;
    }
    cout << "Data parsing successful." << endl;
    cout << "Number of data points: " << list_size << endl;
    cout << endl;

    printComponents(dataset, list_size);

    /*
    NOTE:
        - As per requirement, 4 decimals are to be on display.
    */
    cout << fixed << setprecision(4) << endl;

    /*
    1. Median
    */
    datapoint median = calculateMedian(dataset, list_size);
    cout << "median_x = " << median.x << " - median_y = " << median.y << endl;
    cout << endl;

    /*
    2. Mode
    */
    datapoint mode = calculateMode(dataset, list_size);
    cout << "mode_x = {" << mode.x << "} - mode_y = {" << mode.y << "}" << endl;
    cout << endl;

    /*
    3. Mean
    */
    datapoint mean = calculateMean(dataset, list_size);
    cout << "mean_x = " << mean.x << " - mean_y = " << mean.y << endl;
    cout << endl;

    /*
    4. Variance
    */
    datapoint variance = calculateVariance(dataset, list_size, mean);
    cout << "var_x = " << variance.x << " - var_y = " << variance.y << endl;
    cout << endl;

    /*
    5. Standard deviation
    */
    datapoint stdev = calculateStdev(variance);
    cout << "stdev_x =  " << stdev.x << " - stdev_y = " << stdev.y << endl;
    cout << endl;

    /*
    6/ Mean Absolute Deviations
    */
    datapoint mad = calculateMAD(dataset, list_size, mean);
    cout << "mad_x =  " << mad.x << " - mad_y = " << mad.y << endl;
    cout << endl;

    /*
    7. Third quartile
    */
    datapoint q3 = calculateThirdQuartile(dataset, list_size);
    cout << "Q3_x = " << q3.x << " - Q3_y = " << q3.y << endl;
    cout << endl;

    /*
    8. Skewness
    */
    datapoint skewness = calculateSkewness(dataset, list_size, mean, stdev);
    cout << "skew_x = " << skewness.x << " - skew_y = " << skewness.y << endl;
    cout << endl;

    /*
    9. Kurtosis
    */
    datapoint kurtosis = calculateKurtosis(dataset, list_size, mean, stdev);
    cout << "kurt_x = " << kurtosis.x << " - kurt_y = " << kurtosis.y << endl;
    cout << endl;

    /*
    10. Covariance
    */
    double cov = calculateCovariance(dataset, list_size, mean);
    cout << "cov(x_y) = " << cov << endl;
    cout << endl;

    /*
    11. Pearson correlation coefficient
    */
    double pcc = calculatePcc(dataset, list_size);
    cout << "r(x_y) = " << pcc << endl;
    cout << endl;

    /*
    12. Linear regression
    */
    linearRegFormula(pcc, mean, stdev);
    cout << endl << endl;

    cout << "\t\tASSIGNMENT 1 - GROUP 9" << endl;
    cout << "\ts3878779, s3878779@rmit.edu.vn, Cuong, Vu" << endl;
    cout << "\ts3931980, s3931980@rmit.edu.vn, Anh, Tran" << endl;
    cout << "\ts3884419, s3884419@rmit.edu.vn, Khoa, Pham" << endl;
    cout << "\ts3915185, s3915185@rmit.edu.vn, Vu, Tran" << endl;

    delete[] dataset;
    return 1;
}
