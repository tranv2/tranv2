#pragma once
#include "descriptivestats.h"

/*
Anh Tran

NOTE:  
    - This function calculates covariance of x and y
    
    in main:
    	double cov = calculateCovariance(data, count, mean);
*/
double calculateCovariance(datapoint data[], int count, datapoint mean) {
	double cov = 0;

	//COV = (sum of (x[i] - mean_x)*(y[i] - mean_y))/(count - 1)
	//first calculate the numerator
	for (int i = 0; i < count; i++) {
		cov += (data[i].x - mean.x) * (data[i].y - mean.y);
	}

	//now divide sum by (count - 1)
	cov = cov / (count - 1);

	return cov;
}

/*
Khoa Pham

NOTE: 
    - This function calculates the Pearson colleration coefficient,
    r = (count * sum_xy) - (sum_x * sum_y) / sqrt((count * sum_x2 - pow(sum_x,2)) * (count * sum_y2 - pow(sum_y,2)))

    - In main:
        double pcc = calculatePcc(data, count)
*/

double calculatePcc(datapoint data[], int count) {
    double sum_x = 0, sum_y = 0, sum_xy = 0, sum_x2 = 0, sum_y2 = 0;
    int total = count;
    double r = 0;

    //calculate the sum of variables: x, y, x2, y2, xy
    for (int i = 0; i < count; i++) {
        sum_x += data[i].x;
        sum_y += data[i].y;
        sum_xy += data[i].x * data[i].y;
        sum_x2 += pow(data[i].x, 2);
        sum_y2 += pow(data[i].y, 2);
    }

    //r = (count * sum_xy) - (sum_x * sum_y) / sqrt((count * sum_x2 - pow(sum_x,2)) * (count * sum_y2 - pow(sum_y,2)))
    double nominator = (total * sum_xy) - (sum_x * sum_y);
    double denominator = sqrt((total * sum_x2 - pow(sum_x,2)) * (total * sum_y2 - pow(sum_y,2)));

    return r = nominator / denominator;
}


/*
Khoa Pham

NOTE:
    - This function outputs the Linear Regression formula, y = ax + b

    - In main:
        linearRegFormula(r, mean, stdev);
*/
void linearRegFormula (double r, datapoint mean, datapoint stdev) {

    float a = (r * stdev.y) / stdev.x; 
    float b = mean.y - a * mean.x;

    std::cout << "y = " << a << "x + " << b << std::endl;
}